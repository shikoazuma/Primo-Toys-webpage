# TODO

Build a static HTML page with the assets provided.

There is a Sketch file included with the design for small and large viewports, along with PNGs of each.

Individual assets are exported as SVG.

Make each of the 3 characters jump individually on touch or on mouseover for non-touch devices.

The button should animate on hover (it does not need to link anywhere!)

Feel free to add any additional animations or hover states.

It should work in the latest versions of modern browsers on desktop, mobile and tablet devices.

Put any CSS and JavaScript in separate files.

Feel free to use any libraries (or not).

There is no need to transpile or minify JavaScript or CSS.

Please return all files needed to run the page in a zip file.
